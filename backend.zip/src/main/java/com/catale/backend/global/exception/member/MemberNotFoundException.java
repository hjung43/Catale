package com.catale.backend.global.exception.member;

import lombok.Getter;

@Getter
public class MemberNotFoundException extends RuntimeException{
//    private final ErrorCode errorCode;

    public MemberNotFoundException(){

    }
}
