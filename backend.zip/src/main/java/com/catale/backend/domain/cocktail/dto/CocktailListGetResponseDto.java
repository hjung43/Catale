package com.catale.backend.domain.cocktail.dto;

public class CocktailListGetResponseDto {
}
