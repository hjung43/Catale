package com.catale.backend.domain.review.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QReview is a Querydsl query type for Review
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QReview extends EntityPathBase<Review> {

    private static final long serialVersionUID = -1188178432L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QReview review = new QReview("review");

    public final com.catale.backend.domain.base.QBaseEntity _super = new com.catale.backend.domain.base.QBaseEntity(this);

    public final NumberPath<Integer> bitter = createNumber("bitter", Integer.class);

    public final com.catale.backend.domain.cocktail.entity.QCocktail cocktail;

    public final StringPath content = createString("content");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    public final NumberPath<Long> id = createNumber("id", Long.class);

    //inherited
    public final BooleanPath isDeleted = _super.isDeleted;

    public final com.catale.backend.domain.member.entity.QMember member;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> modifiedAt = _super.modifiedAt;

    public final NumberPath<Integer> rate = createNumber("rate", Integer.class);

    public final NumberPath<Integer> sour = createNumber("sour", Integer.class);

    public final NumberPath<Integer> sparking = createNumber("sparking", Integer.class);

    public final NumberPath<Integer> sweet = createNumber("sweet", Integer.class);

    public QReview(String variable) {
        this(Review.class, forVariable(variable), INITS);
    }

    public QReview(Path<? extends Review> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QReview(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QReview(PathMetadata metadata, PathInits inits) {
        this(Review.class, metadata, inits);
    }

    public QReview(Class<? extends Review> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.cocktail = inits.isInitialized("cocktail") ? new com.catale.backend.domain.cocktail.entity.QCocktail(forProperty("cocktail"), inits.get("cocktail")) : null;
        this.member = inits.isInitialized("member") ? new com.catale.backend.domain.member.entity.QMember(forProperty("member"), inits.get("member")) : null;
    }

}

