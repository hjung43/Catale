package com.catale.backend.domain.cocktail.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QCocktail is a Querydsl query type for Cocktail
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QCocktail extends EntityPathBase<Cocktail> {

    private static final long serialVersionUID = -1440357160L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QCocktail cocktail = new QCocktail("cocktail");

    public final com.catale.backend.domain.base.QBaseEntity _super = new com.catale.backend.domain.base.QBaseEntity(this);

    public final NumberPath<Integer> alc = createNumber("alc", Integer.class);

    public final NumberPath<Integer> base = createNumber("base", Integer.class);

    public final NumberPath<Integer> bitter = createNumber("bitter", Integer.class);

    public final NumberPath<Integer> color1 = createNumber("color1", Integer.class);

    public final NumberPath<Integer> color2 = createNumber("color2", Integer.class);

    public final NumberPath<Integer> color3 = createNumber("color3", Integer.class);

    public final StringPath content = createString("content");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    public final NumberPath<Integer> emotion1 = createNumber("emotion1", Integer.class);

    public final NumberPath<Integer> emotion2 = createNumber("emotion2", Integer.class);

    public final NumberPath<Integer> emotion3 = createNumber("emotion3", Integer.class);

    public final NumberPath<Integer> fruit = createNumber("fruit", Integer.class);

    public final NumberPath<Integer> glass = createNumber("glass", Integer.class);

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final com.catale.backend.domain.image.entity.QImage image;

    public final StringPath ingredient = createString("ingredient");

    //inherited
    public final BooleanPath isDeleted = _super.isDeleted;

    public final NumberPath<Integer> likeCount = createNumber("likeCount", Integer.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> modifiedAt = _super.modifiedAt;

    public final StringPath name = createString("name");

    public final NumberPath<Integer> sour = createNumber("sour", Integer.class);

    public final NumberPath<Integer> sparking = createNumber("sparking", Integer.class);

    public final NumberPath<Integer> sweet = createNumber("sweet", Integer.class);

    public QCocktail(String variable) {
        this(Cocktail.class, forVariable(variable), INITS);
    }

    public QCocktail(Path<? extends Cocktail> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QCocktail(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QCocktail(PathMetadata metadata, PathInits inits) {
        this(Cocktail.class, metadata, inits);
    }

    public QCocktail(Class<? extends Cocktail> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.image = inits.isInitialized("image") ? new com.catale.backend.domain.image.entity.QImage(forProperty("image"), inits.get("image")) : null;
    }

}

