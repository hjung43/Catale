package com.catale.backend.domain.store.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QStore is a Querydsl query type for Store
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QStore extends EntityPathBase<Store> {

    private static final long serialVersionUID = -2060138026L;

    public static final QStore store = new QStore("store");

    public final com.catale.backend.domain.base.QBaseEntity _super = new com.catale.backend.domain.base.QBaseEntity(this);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    public final BooleanPath groupAvailable = createBoolean("groupAvailable");

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final ListPath<com.catale.backend.domain.image.entity.Image, com.catale.backend.domain.image.entity.QImage> images = this.<com.catale.backend.domain.image.entity.Image, com.catale.backend.domain.image.entity.QImage>createList("images", com.catale.backend.domain.image.entity.Image.class, com.catale.backend.domain.image.entity.QImage.class, PathInits.DIRECT2);

    //inherited
    public final BooleanPath isDeleted = _super.isDeleted;

    public final ListPath<com.catale.backend.domain.menu.entity.Menu, com.catale.backend.domain.menu.entity.QMenu> menus = this.<com.catale.backend.domain.menu.entity.Menu, com.catale.backend.domain.menu.entity.QMenu>createList("menus", com.catale.backend.domain.menu.entity.Menu.class, com.catale.backend.domain.menu.entity.QMenu.class, PathInits.DIRECT2);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> modifiedAt = _super.modifiedAt;

    public final BooleanPath parkAvailable = createBoolean("parkAvailable");

    public final BooleanPath petAvailable = createBoolean("petAvailable");

    public final BooleanPath reservationAvailable = createBoolean("reservationAvailable");

    public final BooleanPath wifiAvailable = createBoolean("wifiAvailable");

    public QStore(String variable) {
        super(Store.class, forVariable(variable));
    }

    public QStore(Path<? extends Store> path) {
        super(path.getType(), path.getMetadata());
    }

    public QStore(PathMetadata metadata) {
        super(Store.class, metadata);
    }

}

